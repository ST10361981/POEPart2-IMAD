package com.example.poe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    private lateinit var display: TextView
    private lateinit var editFirst: EditText
    private lateinit var editSecond: EditText
    private lateinit var add: Button
    private lateinit var sub: Button
    lateinit var div: Button
    private lateinit var multiply: Button
    private lateinit var Power: Button
    private lateinit var button2: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        display = findViewById(R.id.display_result)
        editFirst = findViewById(R.id.edit_first)
        editSecond = findViewById(R.id.edit_second)
        add = findViewById(R.id.add)
        sub = findViewById(R.id.subtract)
        div = findViewById(R.id.div)
        multiply = findViewById(R.id.multiply)
        Power = findViewById(R.id.squareroot)
        button2 = findViewById(R.id.SquareRoot)

        add.setOnClickListener {

            val res1 = editFirst.text.toString().toInt()
            val res2 = editSecond.text.toString().toInt()

            addition(res1, res2)
        }

        sub.setOnClickListener {

            val res1 = editFirst.text.toString().toInt()
            val res2 = editSecond.text.toString().toInt()

            subtraction(res1, res2)
        }

        div.setOnClickListener {

            val res1 = editFirst.text.toString().toInt()
            val res2 = editSecond.text.toString().toInt()

            division(res1, res2)
        }

        multiply.setOnClickListener {

            val res1 = editFirst.text.toString().toInt()
            val res2 = editSecond.text.toString().toInt()

            multiplication(res1, res2)
        }

        Power.setOnClickListener {

            val numText = editFirst.text.toString()
            val num = numText.toDoubleOrNull()

            if (num != null) {
                if (num < 0) {
                    val total = sqrt(num)
                    display.text = "Answer: sqrt($numText) = $total"
                } else {
                    val total = sqrt(num)
                    display.text = "Answer: sqrt($numText) = $total"
                }
            }
        }

        button2.setOnClickListener {
            // Call the calculatePower function here with appropriate arguments
            val base = editFirst.text.toString().toDouble()
            val exponent = editSecond.text.toString().toDouble()
            calculatePower(base, exponent)
        }
    }

    private fun addition(res1: Int, res2: Int) {
        val result = res1 + res2
        display.text = result.toString()
    }

    private fun subtraction(res1: Int, res2: Int) {
        val result = res1 - res2
        display.text = result.toString()
    }

    private fun multiplication(res1: Int, res2: Int) {
        val result = res1 * res2
        display.text = result.toString()
    }

    private fun division(res1: Int, res2: Int) {
        val result = res1 / res2
        display.text = result.toString()
    }

    // Move the calculatePower function here
    private fun calculatePower(base: Double, exponent: Double) {
        val result = Math.pow(base, exponent)
        display.text = "Result: $result"
    }
}
